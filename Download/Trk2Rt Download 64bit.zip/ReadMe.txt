
To install the 64 bit version of Trk2Rt and create a desktop icon,
double click setup.exe

Please see the User's Guide.

